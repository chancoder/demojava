"use strict";
const tl = require('vsts-task-lib/task');
const path = require('path');
const Util = require('./util');
var win = tl.osType().match(/^Win/);
tl.debug('win: ' + win);
// extractors
var xpUnzipLocation = win ? null : xpUnzipLocation = tl.which('unzip', false);
var winSevenZipLocation = path.join(__dirname, '7zip/7z.exe');
function unzip(file, destinationFolder) {
    if (win) {
        sevenZipExtract(file, destinationFolder);
    }
    else {
        unzipExtract(file, destinationFolder);
    }
}
exports.unzip = unzip;
function unzipExtract(file, destinationFolder) {
    tl.debug('Extracting file: ' + file);
    if (typeof xpUnzipLocation == "undefined") {
        xpUnzipLocation = tl.which('unzip', true);
    }
    var unzip = tl.tool(xpUnzipLocation);
    unzip.arg(file);
    unzip.arg('-d');
    unzip.arg(destinationFolder);
    return handleExecResult(unzip.execSync(getOptions()), file);
}
function sevenZipExtract(file, destinationFolder) {
    tl.debug('Extracting file: ' + file);
    var sevenZip = tl.tool(winSevenZipLocation);
    sevenZip.arg('x');
    sevenZip.arg('-o' + destinationFolder);
    sevenZip.arg(file);
    return handleExecResult(sevenZip.execSync(getOptions()), file);
}
function handleExecResult(execResult, file) {
    if (execResult.code != tl.TaskResult.Succeeded) {
        tl.debug('execResult: ' + JSON.stringify(execResult));
        var message = 'Extraction failed for file: ' + file +
            '\ncode: ' + execResult.code +
            '\nstdout: ' + execResult.stdout +
            '\nstderr: ' + execResult.stderr +
            '\nerror: ' + execResult.error;
        throw new UnzipError(message);
    }
}
function getOptions() {
    var execOptions = {
        silent: true,
        outStream: new Util.StringWritable({ decodeStrings: false }),
        errStream: new Util.StringWritable({ decodeStrings: false }),
    };
    return execOptions;
}
class UnzipError extends Error {
}
exports.UnzipError = UnzipError;
